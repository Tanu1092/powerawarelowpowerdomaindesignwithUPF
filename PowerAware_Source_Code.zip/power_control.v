`timescale 1ns/1ps
module power_control (
    input        clk,
    input        reset_n,
    input        power_on,
    input        isolate,
    input        D,
    output reg   Q,
    output       Q_iso
);
always @(posedge clk or negedge reset_n) begin
    if (!reset_n)
        Q <= 1'b0;
    else if (power_on)
        Q <= D;
end

// When the switchable domain is OFF or isolation is asserted,
// the signal seen by the always-on domain is clamped to 0.
assign Q_iso = isolate ? 1'b0 : (power_on ? Q : 1'b0);

endmodule
