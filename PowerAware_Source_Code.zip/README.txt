PowerAware – Low-Power Domain Design with UPF
================================================

Source files:
1. alu.v              - 8-bit ALU RTL
2. tb_alu.v           - ALU simulation testbench
3. power_control.v    - switchable-domain, isolation demonstration
4. tb_power_control.v - low-power simulation testbench
5. power_intent.upf   - UPF power-intent example

Icarus Verilog simulation:
--------------------------------
iverilog -o alu_sim alu.v tb_alu.v
vvp alu_sim

iverilog -o power_sim power_control.v tb_power_control.v
vvp power_sim

The commands generate:
- alu_wave.vcd
- power_control.vcd

Open a waveform:
--------------------------------
gtkwave alu_wave.vcd
gtkwave power_control.vcd

Important:
--------------------------------
The UPF file is a power-intent example. Actual UPF support,
library cells, power-switch models, isolation cells and retention
cells depend on the EDA tool and technology library.
