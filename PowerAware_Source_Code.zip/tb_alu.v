`timescale 1ns/1ps
module tb_alu;
reg [7:0] A, B;
reg [2:0] op;
wire [7:0] Y;
wire carry;

alu dut (.A(A), .B(B), .op(op), .Y(Y), .carry(carry));

initial begin
    $dumpfile("alu_wave.vcd");
    $dumpvars(0, tb_alu);

    A=8'h05; B=8'h03; op=3'b000; #10;
    A=8'h05; B=8'h03; op=3'b001; #10;
    A=8'h05; B=8'h03; op=3'b010; #10;
    A=8'h05; B=8'h03; op=3'b011; #10;
    A=8'h05; B=8'h03; op=3'b100; #10;
    A=8'h05; B=8'h03; op=3'b101; #10;
    A=8'h05; B=8'h03; op=3'b110; #10;
    A=8'h05; B=8'h05; op=3'b111; #10;

    $finish;
end

always @(A or B or op or Y or carry)
    $display("Time=%0t A=%h B=%h op=%b Y=%h carry=%b",
             $time,A,B,op,Y,carry);
endmodule
