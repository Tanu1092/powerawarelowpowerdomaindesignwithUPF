`timescale 1ns/1ps
module tb_power_control;
reg clk, reset_n, power_on, isolate, D;
wire Q, Q_iso;

power_control dut (
    .clk(clk), .reset_n(reset_n), .power_on(power_on),
    .isolate(isolate), .D(D), .Q(Q), .Q_iso(Q_iso)
);

always #5 clk = ~clk;

initial begin
    $dumpfile("power_control.vcd");
    $dumpvars(0, tb_power_control);

    clk=0; reset_n=0; power_on=0; isolate=1; D=0;
    #12 reset_n=1;

    // Normal operation
    #3 power_on=1; isolate=0; D=1;
    #10 D=0;
    #10 D=1;

    // Power-down with isolation
    #5 isolate=1; power_on=0;
    #20;

    // Wake-up
    power_on=1;
    #5 isolate=0; D=1;
    #20;

    $finish;
end

always @(posedge clk)
    $display("Time=%0t power_on=%b isolate=%b D=%b Q=%b Q_iso=%b",
             $time,power_on,isolate,D,Q,Q_iso);
endmodule
