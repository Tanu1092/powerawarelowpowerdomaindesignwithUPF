`timescale 1ns/1ps
module alu (
    input  [7:0] A,
    input  [7:0] B,
    input  [2:0] op,
    output reg [7:0] Y,
    output reg       carry
);
always @(*) begin
    Y = 8'h00;
    carry = 1'b0;
    case (op)
        3'b000: {carry,Y} = A + B;
        3'b001: {carry,Y} = A - B;
        3'b010: Y = A & B;
        3'b011: Y = A | B;
        3'b100: Y = A ^ B;
        3'b101: Y = A << 1;
        3'b110: Y = A >> 1;
        3'b111: Y = (A == B) ? 8'h01 : 8'h00;
        default: Y = 8'h00;
    endcase
end
endmodule
